# OptiFine 1.8.9 M5 SRC
Decompiled source code of OptiFine 1.8.9 M5

### How to use
1) Download [mcp for 1.8.8](http://www.modcoderpack.com/files/mcp918.zip) and [SRGs for 1.8.9](http://mcpbot.bspk.rs/export/mcp/1.8.9/mcp-1.8.9-srg.zip).
2) Extract the mcp zip in your desired folder.
4) Edit the **version.cfg** file in the **conf** folder. Edit both **ClientVersion** and **ServerVersion** to **1.8.9**.
3) Open the SRG zip and extract it in the **conf** folder (replace all files).
4) Run **decompile.bat**
5) Once finishes, open the **src\minecraft** folder and delete it's contents. Extract the OptiFine SRC zip in that folder.
6) Launch your IDE and start modding!


**Not affiliated with Mojang nor OptiFine**
